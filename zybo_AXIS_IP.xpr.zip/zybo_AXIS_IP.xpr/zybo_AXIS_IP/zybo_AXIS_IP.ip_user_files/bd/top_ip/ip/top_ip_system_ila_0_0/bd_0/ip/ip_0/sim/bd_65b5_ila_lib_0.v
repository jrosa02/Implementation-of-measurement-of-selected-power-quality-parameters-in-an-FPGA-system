// (c) Copyright 2023 Advanced Micro Devices, Inc. All rights reserved.
//
// This file contains confidential and proprietary information
// of AMD and is protected under U.S. and
// international copyright and other intellectual property
// laws.
//
// DISCLAIMER
// This disclaimer is not a license and does not grant any
// rights to the materials distributed herewith. Except as
// otherwise provided in a valid license issued to you by
// AMD, and to the maximum extent permitted by applicable
// law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
// WITH ALL FAULTS, AND HEREBY DISCLAIMS ALL WARRANTIES
// AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
// BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
// INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
// (2) AMD shall not be liable (whether in contract or tort,
// including negligence, or under any other theory of
// liability) for any loss or damage of any kind or nature
// related to, arising under or in connection with these
// materials, including for any direct, or any indirect,
// special, incidental, or consequential loss or damage
// (including loss of data, profits, goodwill, or any type of
// loss or damage suffered as a result of any action brought
// by a third party) even if such damage or loss was
// reasonably foreseeable or AMD had been advised of the
// possibility of the same.
//
// CRITICAL APPLICATIONS
// AMD products are not designed or intended to be fail-
// safe, or for use in any application requiring fail-safe
// performance, such as life-support or safety devices or
// systems, Class III medical devices, nuclear facilities,
// applications related to the deployment of airbags, or any
// other applications that could lead to death, personal
// injury, or severe property or environmental damage
// (individually and collectively, "Critical
// Applications"). Customer assumes the sole risk and
// liability of any use of AMD products in Critical
// Applications, subject only to applicable laws and
// regulations governing limitations on product liability.
//
// THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
// PART OF THIS FILE AT ALL TIMES.
//
// DO NOT MODIFY THIS FILE.
`timescale 1ns / 1ps
module bd_65b5_ila_lib_0 (
clk,


probe0,
probe1,
probe2,
probe3,
probe4,
probe5,
probe6,
probe7,
probe8,
probe9,
probe10,
probe11,
probe12,
probe13,
probe14,
probe15,
probe16,
probe17,
probe18,
probe19,
probe20,
probe21,
probe22,
probe23,
probe24,
probe25,
probe26,
probe27,
probe28,
probe29,
probe30,
probe31,
probe32,
probe33,
probe34,
probe35,
probe36,
probe37,
probe38,
probe39,
probe40,
probe41,
probe42,
probe43,
probe44,
probe45,
probe46,
probe47,
probe48,
probe49,
probe50,
probe51,
probe52,
probe53,
probe54,
probe55,
probe56,
probe57,
probe58,
probe59,
probe60,
probe61,
probe62,
probe63,
probe64,
probe65,
probe66,
probe67,
probe68,
probe69,
probe70,
probe71,
probe72,
probe73,
probe74,
probe75,
probe76,
probe77,
probe78,
probe79,
probe80,
probe81,
probe82,
probe83,
probe84,
probe85,
probe86,
probe87,
probe88,
probe89,
probe90,
probe91,
probe92,
probe93,
probe94,
probe95,
probe96,
probe97,
probe98,
probe99,
probe100
);

input clk;


input [1 : 0] probe0;
input [31 : 0] probe1;
input [1 : 0] probe2;
input [3 : 0] probe3;
input [11 : 0] probe4;
input [3 : 0] probe5;
input [1 : 0] probe6;
input [2 : 0] probe7;
input [3 : 0] probe8;
input [2 : 0] probe9;
input [1 : 0] probe10;
input [31 : 0] probe11;
input [1 : 0] probe12;
input [3 : 0] probe13;
input [11 : 0] probe14;
input [3 : 0] probe15;
input [1 : 0] probe16;
input [2 : 0] probe17;
input [3 : 0] probe18;
input [2 : 0] probe19;
input [1 : 0] probe20;
input [11 : 0] probe21;
input [1 : 0] probe22;
input [1 : 0] probe23;
input [31 : 0] probe24;
input [11 : 0] probe25;
input [1 : 0] probe26;
input [31 : 0] probe27;
input [11 : 0] probe28;
input [3 : 0] probe29;
input [1 : 0] probe30;
input [2 : 0] probe31;
input [1 : 0] probe32;
input [1 : 0] probe33;
input [2 : 0] probe34;
input [1 : 0] probe35;
input [31 : 0] probe36;
input [1 : 0] probe37;
input [3 : 0] probe38;
input [3 : 0] probe39;
input [1 : 0] probe40;
input [2 : 0] probe41;
input [3 : 0] probe42;
input [2 : 0] probe43;
input [1 : 0] probe44;
input [31 : 0] probe45;
input [1 : 0] probe46;
input [3 : 0] probe47;
input [3 : 0] probe48;
input [1 : 0] probe49;
input [2 : 0] probe50;
input [3 : 0] probe51;
input [2 : 0] probe52;
input [1 : 0] probe53;
input [1 : 0] probe54;
input [1 : 0] probe55;
input [63 : 0] probe56;
input [1 : 0] probe57;
input [63 : 0] probe58;
input [7 : 0] probe59;
input [1 : 0] probe60;
input [2 : 0] probe61;
input [1 : 0] probe62;
input [1 : 0] probe63;
input [2 : 0] probe64;
input [1 : 0] probe65;
input [9 : 0] probe66;
input [2 : 0] probe67;
input [1 : 0] probe68;
input [9 : 0] probe69;
input [2 : 0] probe70;
input [1 : 0] probe71;
input [1 : 0] probe72;
input [1 : 0] probe73;
input [31 : 0] probe74;
input [1 : 0] probe75;
input [31 : 0] probe76;
input [3 : 0] probe77;
input [1 : 0] probe78;
input [1 : 0] probe79;
input [1 : 0] probe80;
input [1 : 0] probe81;
input [1 : 0] probe82;
input [1 : 0] probe83;
input [15 : 0] probe84;
input [2 : 0] probe85;
input [1 : 0] probe86;
input [15 : 0] probe87;
input [2 : 0] probe88;
input [1 : 0] probe89;
input [1 : 0] probe90;
input [1 : 0] probe91;
input [31 : 0] probe92;
input [1 : 0] probe93;
input [31 : 0] probe94;
input [3 : 0] probe95;
input [1 : 0] probe96;
input [1 : 0] probe97;
input [1 : 0] probe98;
input [1 : 0] probe99;
input [1 : 0] probe100;


endmodule
