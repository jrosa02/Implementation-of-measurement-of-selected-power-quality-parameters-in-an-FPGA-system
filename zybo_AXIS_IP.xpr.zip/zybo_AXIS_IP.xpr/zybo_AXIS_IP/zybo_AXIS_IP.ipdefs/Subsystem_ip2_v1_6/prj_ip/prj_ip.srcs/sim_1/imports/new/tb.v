`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/19/2024
// Design Name: 
// Module Name: Subsystem_ip2_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: Testbench for Subsystem_ip2
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module tb;

    // Clock and Reset
    reg  clk = 0;                  // Clock signal
    reg  resetn = 0;               // Active-low reset signal

    // AXI4-Stream Slave Interface
    reg  [31:0] axi4_stream_slave_tdata = 0;  // Data input from Slave
    reg         axi4_stream_slave_tvalid = 0; // Valid signal from Slave
    wire        axi4_stream_slave_tready;     // Ready signal to Slave

    // AXI4-Stream Master Interface
    wire [31:0] axi4_stream_master_tdata;     // Data output from Master
    wire        axi4_stream_master_tvalid;    // Valid signal from Master
    wire        axi4_stream_master_tlast;     // Last signal from Master
    reg         axi4_stream_master_tready = 0; // Ready signal from Master

    // AXI4-Lite Interface
    reg  axi4_lite_aclk = 0;          // AXI4-Lite clock
    reg  axi4_lite_aresetn = 0;       // AXI4-Lite active-low reset
    reg  [31:0] axi4_lite_awaddr = 0; // Write address
    reg         axi4_lite_awvalid = 0;// Write address valid
    reg  [31:0] axi4_lite_wdata = 0;  // Write data
    reg  [3:0]  axi4_lite_wstrb = 0;  // Write strobes
    reg         axi4_lite_wvalid = 0; // Write valid
    reg         axi4_lite_bready = 0; // Write response ready
    reg  [31:0] axi4_lite_araddr = 0; // Read address
    reg         axi4_lite_arvalid = 0;// Read address valid
    reg         axi4_lite_rready = 0; // Read data ready
    wire        axi4_lite_awready;    // Write address ready
    wire        axi4_lite_wready;     // Write ready
    wire [1:0]  axi4_lite_bresp;      // Write response
    wire        axi4_lite_bvalid;     // Write response valid
    wire        axi4_lite_arready;    // Read address ready
    wire [31:0] axi4_lite_rdata;      // Read data
    wire [1:0]  axi4_lite_rresp;      // Read response
    wire        axi4_lite_rvalid;     // Read data valid

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk; // 100 MHz clock
    end

    initial begin
        axi4_lite_aclk = 0;
        forever #5 axi4_lite_aclk = ~axi4_lite_aclk; // 100 MHz clock
    end

    // Reset signal initialization
    initial begin
        resetn = 0;
        axi4_lite_aresetn = 0;
        
        #20 resetn = 1;
        axi4_lite_aresetn = 1;
    end

    // Instantiate the DUT
    Subsystem_ip2 dut (
        .IPCORE_CLK               (clk),                    // Connect to clock signal
        .IPCORE_RESETN            (resetn),                 // Active-low reset signal
        .AXI4_Stream_Master_TREADY(axi4_stream_master_tready), // Master ready
        .AXI4_Stream_Slave_TDATA  (axi4_stream_slave_tdata), // Slave data input
        .AXI4_Stream_Slave_TVALID (axi4_stream_slave_tvalid), // Slave valid
        .AXI4_Lite_ACLK           (axi4_lite_aclk),          // AXI4-Lite clock
        .AXI4_Lite_ARESETN        (axi4_lite_aresetn),       // AXI4-Lite reset
        .AXI4_Lite_AWADDR         (axi4_lite_awaddr),        // Write address
        .AXI4_Lite_AWVALID        (axi4_lite_awvalid),       // Write address valid
        .AXI4_Lite_WDATA          (axi4_lite_wdata),         // Write data
        .AXI4_Lite_WSTRB          (axi4_lite_wstrb),         // Write strobes
        .AXI4_Lite_WVALID         (axi4_lite_wvalid),        // Write valid
        .AXI4_Lite_BREADY         (axi4_lite_bready),        // Write response ready
        .AXI4_Lite_ARADDR         (axi4_lite_araddr),        // Read address
        .AXI4_Lite_ARVALID        (axi4_lite_arvalid),       // Read address valid
        .AXI4_Lite_RREADY         (axi4_lite_rready),        // Read data ready
        .AXI4_Stream_Master_TDATA (axi4_stream_master_tdata), // Master data output
        .AXI4_Stream_Master_TVALID(axi4_stream_master_tvalid), // Master valid
        .AXI4_Stream_Master_TLAST (axi4_stream_master_tlast), // Master last
        .AXI4_Stream_Slave_TREADY (axi4_stream_slave_tready), // Slave ready
        .AXI4_Lite_AWREADY        (axi4_lite_awready),       // Write address ready
        .AXI4_Lite_WREADY         (axi4_lite_wready),        // Write ready
        .AXI4_Lite_BRESP          (axi4_lite_bresp),         // Write response
        .AXI4_Lite_BVALID         (axi4_lite_bvalid),        // Write response valid
        .AXI4_Lite_ARREADY        (axi4_lite_arready),       // Read address ready
        .AXI4_Lite_RDATA          (axi4_lite_rdata),         // Read data
        .AXI4_Lite_RRESP          (axi4_lite_rresp),         // Read response
        .AXI4_Lite_RVALID         (axi4_lite_rvalid)         // Read valid
    );
    
        // Stimulus for testing
    initial begin
        // AXI4-Stream transaction data
        axi4_stream_slave_tdata = 32'h00000678;
        forever #10 axi4_stream_slave_tdata = axi4_stream_slave_tdata + 1;
    end

    // Stimulus for testing
    initial begin
        // AXI4-Stream transaction
        # 40;
        axi4_stream_slave_tvalid = 1;
        axi4_stream_master_tready = 1;

        #(10*2048);
        axi4_stream_slave_tvalid = 0;
        
        #(11*10*2048);
        
        $finish;
    end
endmodule
